# god > 2025-01-30 2:45pm
https://universe.roboflow.com/work-u38om/god-sht1a

Provided by a Roboflow user
License: CC BY 4.0

